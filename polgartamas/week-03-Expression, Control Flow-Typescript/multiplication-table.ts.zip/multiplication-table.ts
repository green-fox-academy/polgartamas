'use strict';

export function multiplicationTable(number: number): void {
  for (let h: number = 1; h <= 10; h++) {
    const result = h * number;
    console.log(`${h} * ${number} = ${result}`);
  }
}
// multiplicationTable(100);

// Create a program that
// prints the multiplication table with number
//
// Example:
// The number 15 should print:
//
// 1 * 15 = 15
// 2 * 15 = 30
// 3 * 15 = 45
// 4 * 15 = 60
// 5 * 15 = 75
// 6 * 15 = 90
// 7 * 15 = 105
// 8 * 15 = 120
// 9 * 15 = 135
// 10 * 15 = 150
